"""Convert Zenodo 14224680 'Evolution of Antibiotic Resistance in Europe 1998-2019' (real ECDC EARS-Net data) for RESIST-X.
Usage: python convert_eu.py summary_AMR_filtered.csv --out data      -> data/eu_aggregate.csv (annual)
Note: the file counts Intermediate+Resistant (N_I_R) together."""
import argparse, pathlib, pandas as pd
a = argparse.ArgumentParser(); a.add_argument("file"); a.add_argument("--out", default="data"); a.add_argument("--min-tested", type=int, default=30)
x = a.parse_args()
d = pd.read_csv(x.file, encoding="utf-8-sig"); d.columns = [c.strip() for c in d.columns]
low = {c.lower(): c for c in d.columns}
need = {"year": "Year", "country": "Country", "antibiotic": "Antibiotic", "n_tested": "N_tested", "n_i_r": "N_I_R"}
miss = [k for k in need if k not in low]
if miss:
    raise SystemExit(f"Missing columns {miss}. Found: {list(d.columns)}")
org = next((low[k] for k in ("organism", "bacteria", "species", "pathogen", "bug") if k in low), None)
o = pd.DataFrame({"Month": pd.to_datetime(d[low["year"]].astype(int).astype(str) + "-01-01"), "Region": d[low["country"]],
                  "Organism": d[org] if org else "Invasive isolates (all reported)", "Antibiotic": d[low["antibiotic"]],
                  "Resistant": pd.to_numeric(d[low["n_i_r"]], errors="coerce"), "Tested": pd.to_numeric(d[low["n_tested"]], errors="coerce")})
o = o.dropna(); o = o[(o.Tested >= x.min_tested) & (o.Resistant <= o.Tested)]
o[["Resistant", "Tested"]] = o[["Resistant", "Tested"]].round().astype(int)
p = pathlib.Path(x.out); p.mkdir(exist_ok=True); o.to_csv(p / "eu_aggregate.csv", index=False)
print(len(o), "rows ->", p / "eu_aggregate.csv", "| organism column:", org or "none (labelled generic)")
